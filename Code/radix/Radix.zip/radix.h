//
// Created by Hevos on 22.11.2022.
//

#ifndef RADIX_RADIX_H
#define RADIX_RADIX_H

#include <stdint.h>
#include <stdio.h>
#include <string.h>

void radix(const char* input, int output);

#endif //RADIX_RADIX_H
